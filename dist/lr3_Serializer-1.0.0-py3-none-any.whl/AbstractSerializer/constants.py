JSON = 'json'
XML = 'xml'
